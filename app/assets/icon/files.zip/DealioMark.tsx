// Dealio brand mark — the "d" monogram (navy bowl/stem + blue filled quarter + dot).
// Faithful to logo.svg. Renders as inline SVG so it scales cleanly and inherits sizing via props.
import * as React from 'react';

type DealioMarkProps = {
  size?: number;          // pixel height/width of the square mark
  className?: string;
  title?: string;
};

/**
 * Dealio "d" mark. Square viewBox; the mark is centered with light padding.
 * Colors are the brand values: ink #0F172A, accent #3B82F6.
 * If you prefer the accent to follow the theme token, swap the fills/strokes
 * for var(--accent) (the dot + quarter) — but the mark is a brand asset, so
 * fixed brand colors are intentional here.
 */
export function DealioMark({ size = 32, className, title = 'Dealio' }: DealioMarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 110 110"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label={title}
    >
      <title>{title}</title>
      {/* d body — navy stroke */}
      <path
        d="M40 25V85H65C72.9565 85 80.5871 81.8393 86.2132 76.2132C91.8393 70.5871 95 62.9565 95 55C95 47.0435 91.8393 39.4129 86.2132 33.7868C80.5871 28.1607 72.9565 25 65 25H40Z"
        stroke="#0F172A"
        strokeWidth="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* filled lower-right quarter — accent blue */}
      <path
        d="M65 55H95C95 62.9565 91.8393 70.5871 86.2132 76.2132C80.5871 81.8393 72.9565 85 65 85V55Z"
        fill="#3B82F6"
      />
      {/* dot — accent blue */}
      <path
        d="M25 60C27.7614 60 30 57.7614 30 55C30 52.2386 27.7614 50 25 50C22.2386 50 20 52.2386 20 55C20 57.7614 22.2386 60 25 60Z"
        fill="#3B82F6"
      />
    </svg>
  );
}

export default DealioMark;
